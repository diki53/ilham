<!-- <?php
$bil1 = 50000;
$bil2 = 3;
$bil3 = 53;

$hitung = (($bil1/$bil2)*$bil3)/1000;
$hasil = floor($hitung);

var_dump($hasil);

?> -->

<?php
$bil1 = 72;
$bil2 = 125;
$bil3 = 1100;

$hitung = ($bil1*$bil2)/$bil3;
$hasil = round($hitung,3);

var_dump($hasil);



?>