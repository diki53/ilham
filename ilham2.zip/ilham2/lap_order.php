<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Surat Order!</title>
  </head>
  <body>
  <div class="container">

  <table class="table table-borderless">
  <thead>
    <tr>
      <th scope="col">PT. Mitra Adika Solusindo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th></th>
      <td> <strong>Surat Order</strong></td>
      <td></td>
      <td></td>
    </tr>
    <?php
    include "koneksi.php";
    $id = $_GET['id'];
    if ($id >= 1) {
    $data = mysqli_query($koneksi, "SELECT * FROM tb_order where id_order='$id'");
    while($row = mysqli_fetch_assoc($data)){
      $tanggal = $row['tanggal'];
      $date = date('d F Y', strtotime("$tanggal"));
    ?>
    <tr>
      <td>Nama Marketing : <?= $row ['nama_marketing'];?></td>
      <td></td>
      <td>No SO : <?= $row ['no_so'];?></td>
    </tr>
    <tr>
      <td>Nama Pelanggan : <?= $row ['nama_pelanggan'];?></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>Tanggal : <?= $date;?></td>
      <td> </td>
      <td></td>
    </tr>
  </tbody>
</table>
<!-- ================================================================================================== -->
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Item Barang</th>
      <th scope="col">Jenis Bahan</th>
      <th scope="col">Qty</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td><?= $row ['nama_brg'];?></td>
      <td><?= $row ['jenis_bahan'];?></td>
      <td><?= $row ['qty'];?></td>
    </tr>
  </tbody>
</table>
<i>Item yang sudah di tanda tangani oleh marketing</i>
<p><i>sudah bisa di proses Job Order dan akan di produksi</i></p>

<div class="text-right">
<p>TTD Marketing &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;</p>
<br>
<br>
<p>(<?= $row ['nama_marketing'];?>) &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;</p>
</div>
<?php }
    }
?>

</div>

<script>
window.print();
</script>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>