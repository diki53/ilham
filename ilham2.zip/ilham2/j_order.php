<!DOCTYPE html>
<html>
<head>
</head>
<body>
<a class="btn btn-primary" href="?page=tj_order">
  Input Job Order
</a>
<br>
<br>

<table class="table table-hover table-bordered"  id="example" width="100%">
    <thead style="background-color : #A9A9A9">
        <tr>
        <th scope="col">No SO</th>
        <th scope="col">Nama Marketing</th>
        <th scope="col">Nama Pelanggan</th>
        <th scope="col">Nama Barang</th>
        <th scope="col">Jenis Bahan</th>
        <th scope="col">Qty</th>
        <th scope="col">Tanggal</th>
        <th scope="col">Detail</th>
        </tr>
    </thead>
    <tbody>
    <?php
    include "koneksi.php";
    $employee = mysqli_query($koneksi,"select * from tb_order order by id_order");
    while($row = mysqli_fetch_array($employee))   
    {
      $tgl = $row['tanggal'];
      $date = date('d/m/Y', strtotime($tgl));
    ?>
    
        <tr class="table-light">
        <td><?= $row['no_so'];?></td>
        <td><?= $row['nama_marketing'];?></td>
        <td><?= $row['nama_pelanggan'];?></td>
        <td><?= $row['nama_brg'];?></td>
        <td><?= $row['jenis_bahan'];?></td>
        <td><?= $row['qty'];?></td>
        <td><?= $date;?></td>
        <td class="center">
        <a href="?page=t_order&action=detail&id=<?= $row['id_order'];?>">Edit<span class="glyphicon glyphicon-folder-open"></span></a>
        |
        <a href="lap_j_order.php?id=<?= $row['id_order'];?>" target="_blank">Cetak<span class="glyphicon glyphicon-folder-open"></span></a>
        </td>
        </tr>
    <?php
    }
    ?>
    </tbody>
    </table>


    <!-- Latest compiled and minified CSS -->

</body>
</html>