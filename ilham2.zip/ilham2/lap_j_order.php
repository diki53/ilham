<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Job Order!</title>
  </head>
  <body>
  <div class="container">
  <div class="card card-body border-dark">
<div class="panel panel-danger">
<!-- ================================================================================================== -->
<form action="" method="post">
  <div class="form-group row">
    <label for="colFormLabelSm" class="col-md-2 col-form-label col-form-label-md">Tanggal Pesanan</label>
      <div class="col-md-4">
        <input type="email" class="form-control form-control-md border-dark" id="colFormLabelSm">
      </div>

    <div class="col-md-6 text-center">
      <h3><strong>JOB ORDER</strong></h3>
    </div>
  </div>

  <div class="form-group row">
    <label for="colFormLabelSm" class="col-md-2 col-form-label col-form-label-md">Tanggal Selesai</label>
    <div class="col-md-4">
      <input type="email" class="form-control form-control-md border-dark" id="colFormLabelSm">
    </div>

    <label for="colFormLabelSm" class="col-md-1 col-form-label col-form-label-md">No</label>
    <div class="col-md-5">
      <input type="email" class="form-control form-control-md border-dark" id="colFormLabelSm" placeholder="12345 jhgf">
    </div>
  </div>

  <div class="form-group row">
    <label for="colFormLabelSm" class="col-md-2 col-form-label col-form-label-md">Referensi Kerja</label>
    <div class="col-md-10">
      <input type="email" class="form-control form-control-md border-dark" id="colFormLabelSm">
    </div>
  </div>

  <div class="form-group row">
    <label for="colFormLabelSm" class="col-md-2 col-form-label col-form-label-md">Jenis Bahan</label>
    <div class="col-md-10">
      <input type="email" class="form-control form-control-md border-dark" id="colFormLabelSm">
    </div>
  </div>

  <div class="form-group row">
    <label for="colFormLabelSm" class="col-md-2 col-form-label col-form-label-md">Quantity Order</label>
    <div class="col-md-2">
      <input type="email" class="form-control form-control-md border-dark" id="colFormLabelSm">
      <small id="passwordHelpInline" class="text-muted form-inline">
      <i>Pcs</i>
    </small>
    </div>

    <label for="colFormLabelSm" class="col-sm-1 col-form-label col-form-label-md">Isi</label>
    <div class="col-md-3">
      <input type="email" class="form-control form-control-md border-dark" id="colFormLabelSm">
      <small id="passwordHelpInline" class="text-muted form-inline">
      <i>Pcs/Roll</i>
    </small>
    </div>
   

    <label for="colFormLabelSm" class="col-sm-1 col-form-label col-form-label-md">Jumlah</label>
    <div class="col-md-3">
      <input type="email" class="form-control form-control-md border-dark" id="colFormLabelSm">
      <small id="passwordHelpInline" class="text-muted form-inline">
      <i>Rolls</i>
    </small>
    </div>
  </div>
</form>
<!-- ======================================================================================================== -->

<p>Ukuran <i>(Horisontal X Vertikal X Kolom)</i></p>

<!-- ======================================================================================================= -->
<table>
<tr>
<td class="table-bordered border-dark" width="10%">07</td>
<td><i>mm</i></td>
<td>&emsp;</td>

<td>X</td>
<td>&nbsp;</td>
<td class="table-bordered border-dark" width="20%">50</td>
<td><i>mm</i></td>
<td>&emsp;</td>

<td>X</td>

<td class="table-bordered border-dark" width="20%">1</td>
<td><i>Kolom &emsp;</i></td>


<td>Core :</td>
<td class="table-bordered border-dark" width="20%">1</td>
<td><i>Inch</i></td>
</tr>

<tr>
<td>&nbsp; </td>
</tr>

<tr>
<td>Gap :</td>
<td>Kiri</td>
<td class="table-bordered border-dark" width="20%">1,5</td>
<td><i>mm</i></td>


<td>Kanan</td>
<td class="table-bordered border-dark" width="20%">1,5</td>
<td><i>mm</i></td>
<td></td>

<td>Gulungan(Face)</td>
<td class="table-bordered border-dark" width="20%">0</td>
<td><i>In/Out</i></td>
</tr>

<tr>
<td>&nbsp;</td>
</tr>

<tr>
<td></td>
<td>Atas</td>
<td class="table-bordered border-dark" width="20%">1,5</td>
<td><i>mm &emsp;</i></td>



<td>Bawah</td>
<td class="table-bordered border-dark" width="20%">1,5</td>
<td><i>mm</i></td>
<td></td>


<td>Black/Mark</td>
<td class="table-bordered border-dark" width="20%">0</td>
<td>Y/N</td>

<td>Porporasi</td>
<td class="table-bordered border-dark" width="20%">66</td>
<td>Y/N</td>
</tr>

<tr>
<td>&nbsp;</td>
</tr>
</table>
<!-- ===================================================================================================== -->

<table class="table">
  <thead>
    <tr>
      <th scope="col" class="table-bordered border-dark"></th>
      <th scope="col" class="table-bordered border-dark"></th>
      <th scope="col" class="table-bordered border-dark"></th>
      <th scope="col" class="table-bordered border-dark"></th>
      <th scope="col" class="table-bordered border-dark"></th>
    </tr>
  </thead>
  <tbody>
  <?php
    $bil1 = 50000;
    $bil2 = 3;
    $bil3 = 53;
    $bil4 = 72;
    $bil5 = 125;
    $bil6 = 1100;

    $hitung = (($bil1/$bil2)*$bil3)/1000;
    $hasil = floor($hitung);

    $hitung2 = ($bil4*$bil5)/$bil6;
    $hasil2 = round($hitung2,3);
  ?>
    <tr>
      <td class="table-bordered border-dark text-center">Bahan</td>
      <td class="table-bordered border-dark">50.000 / 3</td>
      <td class="table-bordered border-dark">* 53 = <?= $hasil;?> m</td>
      <td class="table-bordered border-dark">&nbsp;</td>
      <td class="table-bordered border-dark">&nbsp;</td>
    </tr>
    <tr>
      <td class="table-bordered border-dark text-center">Core 1"</td>
      <td class="table-bordered border-dark">72 x 125</td>
      <td class="table-bordered border-dark">/ 1.100 = <?= $hasil2;?> Batang</td>
      <td class="table-bordered border-dark">&nbsp;</td>
      <td class="table-bordered border-dark">&nbsp;</td>
    </tr>
  </tbody>
</table>

<table width="25%" align="right">
  <thead>
    <tr>
      <th scope="col" class="table-bordered border-dark">Checker :</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th  height="70px" class="table-bordered border-dark"></th>
    </tr>
  </tbody>
</table>
<br>
<br>
<br>
<br>
<br>

<table width="25%" align="right">
  <thead>
    <tr>
      <th scope="col" class="table-bordered border-dark text-center"><i>Approval Signature :</i></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th  height="70px" class="table-bordered border-dark"></th>
    </tr>

  </tbody>
</table>

</div>
</div>
</div>

<script>
window.print();
</script>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>