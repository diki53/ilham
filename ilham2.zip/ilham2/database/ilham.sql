-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2020 at 07:39 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ilham`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_order`
--

CREATE TABLE `tb_order` (
  `id_order` int(11) NOT NULL,
  `no_so` varchar(15) NOT NULL,
  `nama_marketing` varchar(50) NOT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `nama_brg` varchar(50) NOT NULL,
  `jenis_bahan` varchar(50) NOT NULL,
  `qty` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_order`
--

INSERT INTO `tb_order` (`id_order`, `no_so`, `nama_marketing`, `nama_pelanggan`, `tanggal`, `nama_brg`, `jenis_bahan`, `qty`) VALUES
(1, 'SO/04/MD0KL31', 'Diki Romadoni', 'Agus Riyan', '2020-01-30', 'Meja', 'Kayu', '5'),
(2, 'SO/05/MD0KL31', 'Ilham Maulana', 'res', '2020-01-31', 'hgfz', 'uytr', '4'),
(3, 'SO/06/MD0KL31', 'lkjh', 'lkjh', '2020-02-07', 'hgfz', 'uytr', '4'),
(4, 'SO/07/MD0KL31', 'lkjhgf', 'uygfd', '2020-01-30', 'kjhg', 'kjhg', '2'),
(5, 'SO/08/MD0KL01', 'qwerty', 'wertyu', '2020-02-01', 'asdfg', 'df', '10'),
(6, 'SO/09/MD0KL01', 'lkjhgf', 'wertyu', '2001-02-20', 'asdfg', 'df', '6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_order`
--
ALTER TABLE `tb_order`
  ADD PRIMARY KEY (`id_order`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_order`
--
ALTER TABLE `tb_order`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
