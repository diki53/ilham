<!-- ========================== I N S E R T  ======================================== -->
<?php
date_default_timezone_set('Asia/Jakarta');
include 'koneksi.php';

if(isset($_POST['submit'])){
    $nama_marketing = $_POST['nama_marketing'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $tanggal = $_POST['tanggal'];
    $nama_brg = $_POST['nama_brg'];
    $jenis_bahan = $_POST['jenis_bahan'];
    $qty = $_POST['qty'];

// ====================================== no order ====================================================

// mencari kode barang dengan nilai paling besar
$query = "SELECT max(no_so) as maxKode FROM tb_order";
$hasil = mysqli_query($koneksi,$query);
$data = mysqli_fetch_array($hasil);
$no_so = $data['maxKode'];

// mengambil angka atau bilangan dalam kode anggota terbesar,
// dengan cara mengambil substring mulai dari karakter ke-1 diambil 6 karakter
// misal 'BRG001', akan diambil '001'
// setelah substring bilangan diambil lantas dicasting menjadi integer
$noUrut = (int) substr($no_so, 3);

// bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
$noUrut++;

// membentuk kode anggota baru
// perintah sprintf("%03s", $noUrut); digunakan untuk memformat string sebanyak 3 karakter
// misal sprintf("%03s", 12); maka akan dihasilkan '012'
// atau misal sprintf("%03s", 1); maka akan dihasilkan string '001'
$char = "SO/";
$char2 = "/MD0KL";
$kode = sprintf("%02s", $noUrut);
$tgl = date("d");
$no_s = $char.$kode.$char2.$tgl;

// ====================================== akhir no order ====================================================

    mysqli_query($koneksi, "INSERT into tb_order values('','$no_s','$nama_marketing','$nama_pelanggan','$tanggal','$nama_brg','$jenis_bahan','$qty')");

    echo "
    <script>
        alert('Data Berhasil Ditambahkan !');
        window.location.href='?page=d_order';
    </script>"
    ?>
    <?php
    exit;
    }
    ?>
<!-- ============================== D E L E T E ============================== -->
<?php
if(isset($_POST['delete'])){
include "koneksi.php";
$id = $_POST['id'];

mysqli_query($koneksi, "delete from tb_order where id_order='$id'");

echo "
<script>
	alert('Data Berhasil Dihapus !');
	window.location.href='./?page=d_order';
</script>"
?>
<?php
}
?>
<!-- =============================== U P D A T E ============================= -->
<?php
if(isset($_POST['update'])){
include "koneksi.php";
$id = $_POST['id'];
$nama_marketing = $_POST['nama_marketing'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$tanggal = $_POST['tanggal'];
$nama_brg = $_POST['nama_brg'];
$jenis_bahan = $_POST['jenis_bahan'];
$qty = $_POST['qty'];

mysqli_query($koneksi, "update tb_order set nama_marketing='$nama_marketing', nama_pelanggan='$nama_pelanggan', tanggal='$tanggal', nama_brg='$nama_brg', jenis_bahan='$jenis_bahan', qty='$qty' where id_order='$id'");

echo "
<script>
	alert('Data Berhasil Di Ubah !');
	window.location.href='./?page=d_order';
</script>"
?>
<?php

}
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>

<a class="btn btn-primary" href="?page=d_order">
  Kembali
</a>
<br>
<br>


  <?php
error_reporting(0);
include "koneksi.php";
$id = $_GET['id'];
if ($id >= 1) {
    $data = mysqli_query($koneksi, "select * from tb_order where id_order='$id'");
    while ($detail=mysqli_fetch_array($data)) {
    ?>
<div class="panel panel-danger">
<div class="card card-body">
<div class="text-center">
<h3>UBAH DATA SURAT ORDER NO : 
<div class="text-danger" >
<?= $detail['no_so'];?>
</div>
</h3>
</div>
<form class="form-horizontal" action="" method="post">

<div class="form-row">
    <div class="form-group col-md-6">
      <label for="nama_marketing">Nama Marketing</label>
      <input type="text" class="form-control" name="nama_marketing" id="nama_marketing" value="<?= $detail['nama_marketing'];?>">
    </div>
    <div class="form-group col-md-6">
      <label for="nama_pelanggan">Nama Pelanggan</label>
      <input type="text" class="form-control" name="nama_pelanggan" id="nama_pelanggan" value="<?= $detail['nama_pelanggan'];?>">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-2">
      <label for="tanggal">Tanggal</label>
      <input type="date" class="form-control" name="tanggal" id="tanggal" value="<?= $detail['tanggal'];?>">
    </div>
    <div class="form-group col-md-6">
      <label for="nama_brg">Nama Barang</label>
      <input type="text" class="form-control" name="nama_brg" id="nama_brg" value="<?= $detail['nama_brg'];?>">
    </div>
    <div class="form-group col-md-4">
      <label for="jenis_bahan">Jenis Bahan</label>
      <input type="text" class="form-control" name="jenis_bahan" id="jenis_bahan" value="<?= $detail['jenis_bahan'];?>">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="qty">Qty</label>
      <input type="text" class="form-control" name="qty" id="qty" value="<?= $detail['qty'];?>">
    </div>
  </div>

  <div class="form-group text-center">
    <div class="col-sm-offset-2 col-sm-12">
    <input type="hidden" name="id" value="<?= $detail ['id_order'];?>">
    <button type="submit" name="update" class="btn btn-primary">Update</button>
    <button type="submit" name="delete" class="btn btn-primary">Delete</button>
    </div>
  </div>
</form>
</div>
</div>
<?php
    }
    ?>
    <?php
}else{
    ?>

<div class="card card-body">
<div class="panel panel-danger">
<div class="text-center">
<h3>INPUT DATA ORDER</h3>
<hr>
</div>
<form action="" method="post">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="nama_marketing">Nama Marketing</label>
      <input type="text" class="form-control" name="nama_marketing" id="nama_marketing">
    </div>
    <div class="form-group col-md-6">
      <label for="nama_pelanggan">Nama Pelanggan</label>
      <input type="text" class="form-control" name="nama_pelanggan" id="nama_pelanggan">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-2">
      <label for="tanggal">Tanggal</label>
      <input type="date" class="form-control" name="tanggal" id="tanggal">
    </div>
    <div class="form-group col-md-6">
      <label for="nama_brg">Nama Barang</label>
      <input type="text" class="form-control" name="nama_brg" id="nama_brg">
    </div>
    <div class="form-group col-md-4">
      <label for="jenis_bahan">Jenis Bahan</label>
      <input type="text" class="form-control" name="jenis_bahan" id="jenis_bahan">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="qty">Qty</label>
      <input type="text" class="form-control" name="qty" id="qty">
    </div>
  </div>
  <div class="form-group text-center">
    <div class="col-sm-offset-2 col-sm-12">
    <button type="submit" name="submit" class="btn btn-primary">Tambah</button>
    </div>
  </div>
</form>

</div>
<?php
}
?>
  
</div>
</body>
</html>