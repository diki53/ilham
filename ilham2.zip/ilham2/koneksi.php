<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "ilham";

$koneksi = mysqli_connect("$host","$user","$pass","$db");




?>