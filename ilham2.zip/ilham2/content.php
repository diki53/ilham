<?php
if(@$_GET['page'] == "") {
  include "home.php";  
}else if(@$_GET['page'] == "home") {
  include "home.php";
}else if(@$_GET['page'] == "d_order") {
  include "d_order.php";
}else if(@$_GET['page'] == "t_order") {
  include "t_order.php";
}else if(@$_GET['page'] == "j_order") {
  include "j_order.php";
}else if(@$_GET['page'] == "tj_order") {
  include "tj_order.php";
}else if(@$_GET['page'] == "t_sk") {
  include "input_sidang_sk.php";
}else if(@$_GET['page'] == "lap_kp") {
  include "lap_kp.php";
}else if(@$_GET['page'] == "lap_sk") {
  include "lap_sk.php";
}
?>